// Component Imports
import Checkout from '@views/front-pages/CheckoutPage'

const CheckoutPage = () => {
  return <Checkout />
}

export default CheckoutPage
